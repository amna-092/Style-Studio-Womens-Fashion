STYLE STUDIO — WOMEN'S FASHION WEBSITE
========================================

Technology: HTML5, CSS3, Vanilla JavaScript only.
No Python, Flask, Django, React, or backend is used.

FILES
-----
index.html       Home page
shop.html        Product listing, filters, sorting, shopping bag
about.html       Brand story page
contact.html     Contact form demo
css/style.css    Responsive design and styling
js/script.js     Product data, cart, filters, menu and form interactions

HOW TO RUN
----------
1. Extract the ZIP file.
2. Open the Style-Studio-Womens-Fashion folder.
3. Double-click index.html, or open the folder in Visual Studio Code.
4. For the best development experience, use the VS Code Live Server extension.

NOTES
-----
- Product images are loaded from Unsplash, so an internet connection is required for them.
- Cart contents are stored in the browser using LocalStorage.
- Checkout, contact form and newsletter are frontend demonstrations only.
- Prices are sample prices in Pakistani rupees (Rs.).
- Replace the sample products, images, prices, email and social links with your own store details before publishing.
